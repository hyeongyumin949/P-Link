import React, { useState } from 'react';
import styles from './GroupNotice.module.css';

function NoticeWrite({ onSave, onCancel }) {
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [isImportant, setIsImportant] = useState(false); // 필독 토글

    const handleSubmit = (e) => {
        e.preventDefault();
        
        if (!title.trim() || !content.trim()) {
            alert("제목과 내용을 모두 입력해주세요.");
            return;
        }

        const newNotice = {
            title,
            content,
            isImportant
        };
        
        onSave(newNotice);
    };

    return (
        <div className={styles['notice-write-view']}>
            <h2 className={styles['write-title']}>공지사항 작성</h2>

            <form onSubmit={handleSubmit} className={styles['write-form']}>
                
                {/* 🔑 중요도 토글 */}
                <div className={styles['form-group']}>
                    <label className={styles['toggle-label']}>
                        <input 
                            type="checkbox"
                            checked={isImportant}
                            onChange={(e) => setIsImportant(e.target.checked)}
                            className={styles['important-checkbox']}
                        />
                        <span className={styles['important-text']}>필독 공지로 지정</span>
                    </label>
                </div>
                
                {/* 제목 입력 */}
                <div className={styles['form-group']}>
                    <input 
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="제목을 입력하세요"
                        className={styles['input-title']}
                        required
                    />
                </div>

                {/* 내용 입력 */}
                <div className={styles['form-group']}>
                    <textarea
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        placeholder="공지 내용을 입력하세요"
                        className={styles['textarea-content']}
                        rows="10"
                        required
                    />
                </div>

                {/* 액션 버튼 */}
                <div className={styles['write-actions']}>
                    <button type="button" className={`${styles['btn']} ${styles['btn-cancel']}`} onClick={onCancel}>
                        취소
                    </button>
                    <button type="submit" className={`${styles['btn']} ${styles['btn-write-primary']}`}>
                        작성 완료
                    </button>
                </div>
            </form>
        </div>
    );
}
export default NoticeWrite;