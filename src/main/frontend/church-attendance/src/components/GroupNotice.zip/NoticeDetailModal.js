import React, { useState } from 'react';
import styles from './GroupNotice.module.css';
import { useMemberContext } from '../../MemberContext'; 


// ----------------------------------------------------
// 댓글 섹션 컴포넌트 (Context와 연결)
// ----------------------------------------------------
const CommentSection = ({ noticeId }) => {
    // 🔑 [수정] Context에서 필요한 모든 상태와 액션을 가져옵니다.
    const { 
        currentUserId, 
        currentUserName,
        getCommentsByNoticeId, 
        addComment,
        deleteComment
    } = useMemberContext();
    
    const comments = getCommentsByNoticeId(noticeId); 
    const [newComment, setNewComment] = useState('');

    // 댓글 등록 핸들러
    const handleCommentSubmit = (e) => {
        e.preventDefault();
        if (!newComment.trim()) return;

        const newCommentObj = {
            id: Date.now(),
            authorId: currentUserId,   // 🔑 현재 로그인 사용자 ID 사용
            author: currentUserName,   // 🔑 현재 로그인 사용자 이름 사용
            time: '방금 전',
            text: newComment.trim(),
        };

        addComment(noticeId, newCommentObj); 
        setNewComment('');
    };
    
    // 댓글 삭제 핸들러
    const handleDeleteComment = (commentId) => {
        const confirmed = window.confirm('정말로 이 댓글을 삭제하시겠습니까?');
        if (confirmed) {
            deleteComment(noticeId, commentId);
        }
    };


    return (
        <div className={styles['comment-section']}>
            <h4 className={styles['comment-count']}>댓글 {comments.length}개</h4> 

            {/* 1. 댓글 입력 폼 */}
            <form onSubmit={handleCommentSubmit} className={styles['comment-input-form']}>
                <textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder={`${currentUserName}님, 댓글을 입력하세요...`}
                    className={styles['comment-textarea']}
                    rows="3"
                />
                <button type="submit" className={`${styles['btn']} ${styles['btn-submit-comment']}`}>
                    등록
                </button>
            </form>

            {/* 2. 댓글 목록 */}
            <div className={styles['comment-list']}>
                {comments.map(comment => (
                    <div key={comment.id} className={styles['comment-item']}>
                        <div className={styles['comment-meta']}>
                            <strong className={styles['comment-author']}>{comment.author}</strong>
                            <div style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
                                <span className={styles['comment-time']}>{comment.time}</span>
                                
                                {/* 🔑 [핵심] 작성자에게만 삭제 버튼 노출 */}
                                {comment.authorId === currentUserId && (
                                    <button 
                                        className={styles['comment-delete-btn']}
                                        onClick={() => handleDeleteComment(comment.id)}
                                        style={{
                                            border: 'none', 
                                            background: 'none', 
                                            color: '#dc3545', 
                                            cursor: 'pointer', 
                                            fontSize: '0.8em'
                                        }}
                                    >
                                        삭제
                                    </button>
                                )}
                            </div>
                        </div>
                        <p className={styles['comment-text']}>{comment.text}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};


// ----------------------------------------------------
// 공지사항 상세 보기 모달 (NoticeDetailModal)
// ----------------------------------------------------
function NoticeDetailModal({ isOpen, onClose, noticeData, isUserAdmin }) {
    if (!isOpen || !noticeData) return null;
    
    const { title, author, date, isImportant, content, id } = noticeData;
    const isCurrentUserAuthor = true; // 임시로 true (게시글 작성자 권한)

    // 수정/삭제 버튼 컴포넌트 분리
    const ActionButtons = () => (
        <div className={styles['detail-actions']}>
            <button className={`${styles['btn']} ${styles['btn-edit']}`} onClick={() => alert(`[TODO] ${title} 수정 폼 열기`)}>
                수정
            </button>
            <button className={`${styles['btn']} ${styles['btn-delete']}`} onClick={() => alert(`[TODO] ${title} 삭제 확인`)}>
                삭제
            </button>
        </div>
    );

    return (
        <div className={styles['modal-overlay']}> 
            <div className={`${styles['modal-content']} ${styles['detail-modal-size']}`}>
                
                {/* 1. 상단 정보 */}
                <div className={styles['detail-header-row']}>
                    {isImportant && <span className={styles['detail-marker-important']}>필독</span>}
                </div>

                {/* 2. 제목 및 메타 정보 */}
                <h2 className={styles['detail-title']}>{title}</h2>
                <div className={styles['detail-meta']}>
                    <span>작성자: {author}</span>
                    <span>작성일: {date}</span>
                </div>
                
                {/* 3. 구분선 */}
                <hr className={styles['detail-divider']} />

                {/* 4. 내용 본문 */}
                <div className={styles['detail-content-area']}>
                    <p>{content}</p>
                </div>
                
                {/* 🔑 수정/삭제 버튼 (내용과 댓글 사이) */}
                {isUserAdmin && isCurrentUserAuthor && (
                    <div className={styles['action-buttons-between']}>
                        <ActionButtons />
                    </div>
                )}


                {/* 🔑 댓글 섹션 */}
                <CommentSection noticeId={id} />


                {/* 5. 하단 버튼 영역 (닫기 버튼만) */}
                <div className={styles['detail-footer-actions']}>
                    <button className={`${styles['btn']} ${styles['btn-cancel']}`} onClick={onClose}>
                        닫기
                    </button>
                </div>
            </div>
        </div>
    );
}

export default NoticeDetailModal;