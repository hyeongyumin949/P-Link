import React from 'react';
import styles from './GroupNotice.module.css';

function NoticeList({ notices, isUserAdmin, onWriteClick, onNoticeClick }) { 
    
    const NoticeListItem = ({ notice }) => (
        <div className={styles['list-item']} onClick={() => onNoticeClick(notice)}>
            <div className={styles['item-header']}>
                {/* 필독 마커 */}
                {notice.isImportant && <span className={styles['marker-important']}>필독</span>}
                <span className={styles['item-title']}>{notice.title}</span>
            </div>
            <div className={styles['item-footer']}>
                <span className={styles['item-meta']}>작성자: {notice.author}</span>
                <span className={styles['item-meta']}>날짜: {notice.date}</span>
                {/* ❌ 조회수 제거 */}
            </div>
        </div>
    );

    return (
        <div className={styles['notice-list-view']}>
            
            <div className={styles['list-header-actions']}>
                <h2 className={styles['list-title']}>교구 공지사항</h2>
                {isUserAdmin && (
                    <button 
                        className={`${styles['btn']} ${styles['btn-write-primary']}`}
                        onClick={onWriteClick}
                    >
                        + 글쓰기
                    </button>
                )}
            </div>

            <div className={styles['notice-list']}>
                {notices.length > 0 ? (
                    notices.map(notice => (
                        <NoticeListItem key={notice.id} notice={notice} />
                    ))
                ) : (
                    <p className={styles['no-content']}>등록된 공지사항이 없습니다.</p>
                )}
            </div>
        </div>
    );
}

export default NoticeList;