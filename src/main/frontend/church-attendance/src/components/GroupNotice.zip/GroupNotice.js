import React, { useState } from 'react';
import styles from './GroupNotice.module.css'; 
import NoticeList from './NoticeList';      
import NoticeWrite from './NoticeWrite';    
import NoticeDetailModal from './NoticeDetailModal'; 
import { useMemberContext } from '../../MemberContext'; 

// ----------------------------------------------------
// 임시 데이터 (views 필드 제거)
// ----------------------------------------------------
const initialNotices = [
    { id: 1, title: "[필독] 11월 교구 모임 일정 안내", author: "관리자", date: "2025-10-25", isImportant: true, content: "11월 첫째 주 금요 예배는 사정상 온라인으로 진행되며, 모든 속장님들은 반드시 필히 참석하셔야 합니다. 상세 내용은 다음 주 주보를 확인해 주세요. 내용이 길어질 경우를 대비한 긴 텍스트 예시입니다.", isCurrentUserAuthor: true }, // 작성자 본인 예시
    { id: 2, title: "이번 주 속장 회의 공지", author: "김철수 속장", date: "2025-10-24", isImportant: false, content: "회의 주제는..." },
    { id: 3, title: "주보 확인 부탁드립니다.", author: "관리자", date: "2025-10-20", isImportant: false, content: "주보 다운로드 링크: [링크]" },
];


function GroupNotice() {
    const { members } = useMemberContext();
    
    const [currentView, setCurrentView] = useState('list');
    const [notices, setNotices] = useState(initialNotices);
    
    const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
    const [selectedNotice, setSelectedNotice] = useState(null);
    
    const isUserAdmin = true; // 🔑 [TODO] 권한 임시 지정
    
    // -------------------- 핸들러 --------------------
    
    const handleNoticeClick = (notice) => {
        // [TODO: BACKEND] 조회수 증가 API 호출
        setSelectedNotice(notice);
        setIsDetailModalOpen(true);
    };

    const handleSaveNotice = (newNotice) => {
        const newId = Date.now();
        const newRecord = { 
            ...newNotice, 
            id: newId, 
            author: "관리자", 
            date: new Date().toISOString().slice(0, 10), 
            // ❌ views 필드 제거
            isCurrentUserAuthor: true 
        };
        setNotices(prev => [newRecord, ...prev]);
        setCurrentView('list');
        alert("공지사항이 등록되었습니다!");
    };
    
    const handleViewChange = (viewName) => {
        setCurrentView(viewName);
    };

    // -------------------- 뷰 렌더링 --------------------
    
    const renderView = () => {
        if (currentView === 'write') {
            return <NoticeWrite onSave={handleSaveNotice} onCancel={() => handleViewChange('list')} />;
        }
        
        return (
            <NoticeList 
                notices={notices} 
                isUserAdmin={isUserAdmin}
                onWriteClick={() => handleViewChange('write')} 
                onNoticeClick={handleNoticeClick}
            />
        );
    };

    return (
        <div className={styles['notice-container']}>
            {renderView()}
            
            <NoticeDetailModal
                isOpen={isDetailModalOpen}
                onClose={() => setIsDetailModalOpen(false)}
                noticeData={selectedNotice}
                isUserAdmin={isUserAdmin}
            />
        </div>
    );
}
export default GroupNotice;